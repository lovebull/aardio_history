﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("0.0.0.0")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("aardio")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © aardio.com 2018")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: AssemblyProduct("Aardio.InteropServices")]
[assembly: AssemblyTitle("Aardio.InteropServices")]
[assembly: AssemblyTrademark("")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: ComVisible(false)]
[assembly: Guid("9F0CA52C-7D24-4BF6-8A9B-DBFC45E486A0")]
