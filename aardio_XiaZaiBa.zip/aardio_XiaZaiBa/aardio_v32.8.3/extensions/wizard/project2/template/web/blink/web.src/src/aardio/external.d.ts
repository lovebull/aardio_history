interface External {
    onCounterUpdate(name:string,value:number): void; 
}